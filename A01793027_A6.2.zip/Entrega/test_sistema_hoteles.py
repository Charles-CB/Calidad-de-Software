import unittest
from unittest.mock import patch
from sistema_hoteles import (
    Hotel, Customer, Reservation, save_to_file, load_from_file,
    create_hotel, delete_hotel, display_hotel_info,
    create_customer, delete_customer, display_customer_info,
    create_reservation, cancel_reservation
)


class TestHotel(unittest.TestCase):
    def test_to_dict(self):
        hotel = Hotel("Hotel ABC", "City A", 50)
        expected_dict = {
            "name": "Hotel ABC",
            "location": "City A",
            "num_rooms": 50
        }
        self.assertEqual(hotel.to_dict(), expected_dict)


class TestCustomer(unittest.TestCase):
    def test_to_dict(self):
        customer = Customer("John Doe", "john@example.com")
        expected_dict = {
            "name": "John Doe",
            "email": "john@example.com"
        }
        self.assertEqual(customer.to_dict(), expected_dict)


class TestReservation(unittest.TestCase):
    def test_to_dict(self):
        reservation = Reservation("John Doe", "Hotel ABC")
        expected_dict = {
            "customer_name": "John Doe",
            "hotel_name": "Hotel ABC"
        }
        self.assertEqual(reservation.to_dict(), expected_dict)


class TestFileOperations(unittest.TestCase):
    def setUp(self):
        self.test_filename = 'test_data.json'

    def tearDown(self):
        # Eliminar el archivo de prueba después de cada prueba
        import os
        os.remove(self.test_filename)

    def test_save_and_load_from_file(self):
        data = [{"key": "value"}]
        save_to_file(self.test_filename, data)
        loaded_data = load_from_file(self.test_filename)
        self.assertEqual(loaded_data, data)


class TestHotelManagementFunctions(unittest.TestCase):
    @patch('sistema_hoteles.create_hotel')
    @patch('builtins.input', side_effect=["Hotel A", "Location A", "10"])
    def test_create_hotel(self, mock_input, mock_create_hotel):
        # Simulamos la creación de un hotel
        create_hotel()
        # Verificamos que el archivo contenga el hotel creado
        hotels = load_from_file('hotels.json')
        self.assertEqual(len(hotels), 1)
        self.assertEqual(hotels[0]['name'], "Hotel A")
        self.assertEqual(hotels[0]['location'], "Location A")
        self.assertEqual(hotels[0]['num_rooms'], 10)

    @patch('sistema_hoteles.delete_hotel')
    @patch('builtins.input', side_effect=["Hotel A"])
    def test_delete_nonexistent_hotel(self, mock_input, mock_delete_hotel):
        # Simulamos la eliminación de un hotel que no existe
        delete_hotel()
        # Verificamos que no se haya modificado el archivo
        hotels = load_from_file('hotels.json')
        self.assertEqual(len(hotels), 0)


if __name__ == '__main__':
    unittest.main()
