"""
Este módulo proporciona un sistema de gestión de hoteles, clientes y reservas.
"""
import os
import json


class Hotel:
    """Representa un hotel."""
    def __init__(self, name, location, num_rooms):
        self.name = name
        self.location = location
        self.num_rooms = num_rooms

    def to_dict(self):
        """Devuelve un diccionario que representa el hotel."""
        return {
            "name": self.name,
            "location": self.location,
            "num_rooms": self.num_rooms
        }


class Customer:
    """Representa un cliente."""
    def __init__(self, name, email):
        self.name = name
        self.email = email

    def to_dict(self):
        """Devuelve un diccionario que representa el cliente."""
        return {
            "name": self.name,
            "email": self.email
        }


class Reservation:
    """Representa una reserva."""
    def __init__(self, customer_name, hotel_name):
        self.customer_name = customer_name
        self.hotel_name = hotel_name

    def to_dict(self):
        """Devuelve un diccionario que representa la reserva."""
        return {
            "customer_name": self.customer_name,
            "hotel_name": self.hotel_name
        }


def save_to_file(filename, data):
    """Guarda los datos en un archivo JSON."""
    with open(filename, 'w') as file:
        json.dump(data, file, indent=4)


def load_from_file(filename):
    """Carga los datos desde un archivo JSON."""
    try:
        with open(filename, 'r') as file:
            return json.load(file)
    except FileNotFoundError:
        return []


def create_hotel():
    """Crea un nuevo hotel."""
    print("-- You selected to create a Hotel --")
    name = input("Enter Hotel name: ")
    location = input("Enter Location: ")
    num_rooms = int(input("Enter Number of rooms: "))
    hotel = Hotel(name, location, num_rooms)
    hotels = load_from_file('hotels.json')
    hotels.append(hotel.to_dict())
    save_to_file('hotels.json', hotels)
    print("Hotel created successfully!")
    input("Press Enter to continue...")


def delete_hotel():
    """Elimina un hotel existente."""
    print("-- You selected to delete a Hotel --")
    name = input("Enter Hotel name to delete: ")
    hotels = load_from_file('hotels.json')
    filtered_hotels = [h for h in hotels if h['name'] != name]
    save_to_file('hotels.json', filtered_hotels)
    print("Hotel delete successfully!")
    input("Press Enter to continue...")


def display_hotel_info():
    """Muestra la información de un hotel."""
    print("-- You selected to display a Hotel --")
    name = input("Enter Hotel name to display info: ")
    hotels = load_from_file('hotels.json')
    for hotel in hotels:
        if hotel['name'] == name:
            print("Name:", hotel["name"])
            print("Location:", hotel["location"])
            print("Number of Rooms:", hotel["num_rooms"])
            input("Press Enter to continue...")
            return
    print("Hotel not found")
    input("Press Enter to continue...")


def modify_hotel_info():
    """Modifica la información de un hotel."""
    print("-- You select modify hotel info --")
    name = input("Enter the name of the hotel you want to modify: ")
    hotels = load_from_file('hotels.json')
    found = False
    for hotel in hotels:
        if hotel['name'] == name:
            found = True
            print("Current Information:")
            print("Name:", hotel['name'])
            print("Location:", hotel['location'])
            print("Number of Rooms:", hotel['num_rooms'])
            print("Enter the new information:")
            new_name = input("Enter new name: ")
            new_location = input("Enter new location: ")
            new_num_rooms = int(input("Enter new number of rooms: "))
            # Modificar solo el hotel específico
            hotel['name'] = new_name
            hotel['location'] = new_location
            hotel['num_rooms'] = new_num_rooms
            save_to_file('hotels.json', hotels)
            print("Hotel information updated successfully!")
            input("Press Enter to continue...")
            break
    if not found:
        print("Hotel not found")
        input("Press Enter to continue...")


def create_customer():
    """Crea un nuevo cliente."""
    print("-- You selected to create a Customer --")
    name = input("Enter Customer name: ")
    email = input("Enter Customer email: ")
    customer = Customer(name, email)
    customers = load_from_file('customers.json')
    customers.append(customer.to_dict())
    save_to_file('customers.json', customers)
    print("Customer created successfully!")
    input("Press Enter to continue...")


def delete_customer():
    """Elimina un cliente existente."""
    print("-- You selected to delete a Customer --")
    name = input("Enter Customer name to delete: ")
    customers = load_from_file('customers.json')
    filtered_customers = [c for c in customers if c['name'] != name]
    save_to_file('customers.json', filtered_customers)
    print("Customer deleted successfully!")
    input("Press Enter to continue...")


def display_customer_info():
    """Muestra la información de un cliente."""
    print("-- You selected to display a Customer --")
    name = input("Enter Customer name to display info: ")
    customers = load_from_file('customers.json')
    for customer in customers:
        if customer['name'] == name:
            print("Name:", customer["name"])
            print("Email:", customer["email"])
            input("Press Enter to continue...")
            return
    print("Customer not found")
    input("Press Enter to continue...")


def modify_customer_info():
    """Modifica la información de un cliente."""
    print("-- You select modify customer info --")
    name = input("Enter the name of the customer you want to modify: ")
    customers = load_from_file('customers.json')
    found = False
    for customer in customers:
        if customer['name'] == name:
            found = True
            print("Current Information:")
            print("Name:", customer['name'])
            print("Email:", customer['email'])
            print("Enter the new information:")
            new_name = input("Enter new name: ")
            new_email = input("Enter new email: ")
            # Modificar solo el cliente específico
            customer['name'] = new_name
            customer['email'] = new_email
            save_to_file('customers.json', customers)
            print("Customer information updated successfully!")
            input("Press Enter to continue...")
            break
    if not found:
        print("Customer not found")
        input("Press Enter to continue...")


def create_reservation():
    """Crea una nueva reserva."""
    print("-- You selected to create a Reservation --")
    customer_name = input("Enter Customer name: ")
    hotel_name = input("Enter Hotel name: ")
    reservation = Reservation(customer_name, hotel_name)
    reservations = load_from_file('reservations.json')
    reservations.append(reservation.to_dict())
    save_to_file('reservations.json', reservations)
    print("Reservation created successfully!")
    input("Press Enter to continue...")


def cancel_reservation():
    """Cancela una reserva existente."""
    print("-- You selected to cancel a Reservation --")
    customer_name = input("Enter Customer name: ")
    hotel_name = input("Enter Hotel name: ")
    reservations = load_from_file('reservations.json')
    filtered_reservations = [
        reserv
        for reserv in reservations
        if reserv['customer_name'] != customer_name or
        reserv['hotel_name'] != hotel_name]
    save_to_file('reservations.json', filtered_reservations)
    print("Reservation cancelled successfully!")
    input("Press Enter to continue...")


def display_hotel_menu():
    """Muestra el menú de opciones para hoteles."""
    print("\nHotel Menu:")
    print("1. Create Hotel")
    print("2. Delete Hotel")
    print("3. Display Hotel Info")
    print("4. Modify Hotel Info")
    print("5. Home")


def display_customer_menu():
    """Muestra el menú de opciones para clientes."""
    print("\nCustomer Menu:")
    print("1. Create Customer")
    print("2. Delete Customer")
    print("3. Display Customer Info")
    print("4. Modify Customer Info")
    print("5. Home")


def display_reservation_menu():
    """Muestra el menú de opciones para reservas."""
    print("\nReservation Menu:")
    print("1. Create a Reservation")
    print("2. Cancel a Reservation")
    print("3. Home")


def main_menu():
    """Muestra el menú principal."""
    print("\nHome Menu:")
    print("1. Hotel")
    print("2. Customer")
    print("3. Reservation")
    print("4. Exit")


def clear_screen():
    """Limpia la pantalla de la consola."""
    if os.name == 'posix':
        _ = os.system('clear')
    else:
        _ = os.system('cls')


def main():
    """Función principal del programa."""
    while True:
        clear_screen()
        main_menu()
        option = input("Choose an option: ")
        if option == '1':
            hotel_menu()
        elif option == '2':
            customer_menu()
        elif option == '3':
            reservation_menu()
        elif option == '4':
            break
        else:
            print("Invalid option")
            input("Press Enter to continue...")


def hotel_menu():
    """Menú para las operaciones relacionadas con hoteles."""
    while True:
        clear_screen()
        display_hotel_menu()
        hotel_option = input("Choose an option: ")
        if hotel_option == '1':
            create_hotel()
        elif hotel_option == '2':
            delete_hotel()
        elif hotel_option == '3':
            display_hotel_info()
        elif hotel_option == '4':
            modify_hotel_info()
        elif hotel_option == '5':
            break
        else:
            print("Invalid option")
            input("Press Enter to continue...")


def customer_menu():
    """Menú para las operaciones relacionadas con clientes."""
    while True:
        clear_screen()
        display_customer_menu()
        customer_option = input("Choose an option: ")
        if customer_option == '1':
            create_customer()
        elif customer_option == '2':
            delete_customer()
        elif customer_option == '3':
            display_customer_info()
        elif customer_option == '4':
            modify_customer_info()
        elif customer_option == '5':
            break
        else:
            print("Invalid option")
            input("Press Enter to continue...")


def reservation_menu():
    """Menú para las operaciones relacionadas con reservas."""
    while True:
        clear_screen()
        display_reservation_menu()
        reservation_option = input("Choose an option: ")
        if reservation_option == '1':
            create_reservation()
        elif reservation_option == '2':
            cancel_reservation()
        elif reservation_option == '3':
            break
        else:
            print("Invalid option")
            input("Press Enter to continue...")


if __name__ == "__main__":
    main()
